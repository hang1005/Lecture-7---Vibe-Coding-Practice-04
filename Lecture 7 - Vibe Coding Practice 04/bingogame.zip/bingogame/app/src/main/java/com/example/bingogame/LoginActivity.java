package com.example.bingogame;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private static final String PREF_NAME = "login.xml";
    private static final String KEY_USER = "username";
    private static final String KEY_PASS = "password";

    private EditText etUsername, etPassword;
    private Button btnLogin, btnGoToRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Bind views
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnGoToRegister = findViewById(R.id.btnGoToRegister);

        SharedPreferences prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);


        // Login Button
        btnLogin.setOnClickListener(v -> {
            String inputUser = etUsername.getText().toString().trim();
            String inputPass = etPassword.getText().toString().trim();

            String savedUser = prefs.getString(KEY_USER, "");
            String savedPass = prefs.getString(KEY_PASS, "");

            if (inputUser.equals(savedUser) && inputPass.equals(savedPass)) {
                startActivity(new Intent(this, MainActivity.class));
                finish();
            } else {
                new AlertDialog.Builder(this)
                        .setTitle("Login Failed")
                        .setMessage("Your data is incorrect!! Enter again!")
                        .setPositiveButton("OK", null)
                        .show();
            }
        });

        // Go to Register Page
        btnGoToRegister.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        });
    }
}