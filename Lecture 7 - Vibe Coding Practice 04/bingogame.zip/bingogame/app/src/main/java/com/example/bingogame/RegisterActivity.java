// File: RegisterActivity.java
package com.example.bingogame;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private static final String PREF_NAME = "login.xml";
    private static final String KEY_USER = "username";
    private static final String KEY_PASS = "password";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        EditText etUser = findViewById(R.id.etRegUsername);
        EditText etPass = findViewById(R.id.etRegPassword);
        Button btnReg = findViewById(R.id.btnRegister);

        SharedPreferences prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        btnReg.setOnClickListener(v -> {
            String u = etUser.getText().toString().trim();
            String p = etPass.getText().toString().trim();

            if (u.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "Fill both fields", Toast.LENGTH_SHORT).show();
                return;
            }

            prefs.edit()
                    .putString(KEY_USER, u)
                    .putString(KEY_PASS, p)
                    .apply();

            Toast.makeText(this, "Registered!", Toast.LENGTH_SHORT).show();

            // Go back to Login
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }
}