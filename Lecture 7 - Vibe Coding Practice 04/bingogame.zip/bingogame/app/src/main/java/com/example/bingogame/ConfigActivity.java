package com.example.bingogame;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class ConfigActivity extends AppCompatActivity {

    private static final String PREF_NAME = "login.xml";
    private static final String KEY_USER = "username";
    private static final String KEY_PASS = "password";

    private EditText etExistingUser, etExistingPass, etNewUser, etNewPass;
    private Button btnConfirm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);

        etExistingUser = findViewById(R.id.etExistingUsername);
        etExistingPass = findViewById(R.id.etExistingPassword);
        etNewUser      = findViewById(R.id.etNewUsername);
        etNewPass      = findViewById(R.id.etNewPassword);
        btnConfirm     = findViewById(R.id.btnConfirm);

        SharedPreferences prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        btnConfirm.setOnClickListener(v -> {
            String oldUser = etExistingUser.getText().toString().trim();
            String oldPass = etExistingPass.getText().toString().trim();
            String newUser = etNewUser.getText().toString().trim();
            String newPass = etNewPass.getText().toString().trim();

            String savedUser = prefs.getString(KEY_USER, "");
            String savedPass = prefs.getString(KEY_PASS, "");

            // a. Check existing credentials
            if (!oldUser.equals(savedUser) || !oldPass.equals(savedPass)) {
                showDialog("Existing username/password is not correct!");
                return;
            }

            // b. If both new fields are empty → no change
            if (newUser.isEmpty() && newPass.isEmpty()) {
                showDialog("New username/password is not entered! Data remains unchanged");
                return;
            }

            // c. Update SharedPreferences
            SharedPreferences.Editor editor = prefs.edit();
            if (!newUser.isEmpty()) editor.putString(KEY_USER, newUser);
            if (!newPass.isEmpty()) editor.putString(KEY_PASS, newPass);
            editor.apply();

            showDialog("New username/password is confirmed! Data is updated");
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    private void showDialog(String message) {
        new AlertDialog.Builder(this)
                .setTitle("Configuration")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }
}