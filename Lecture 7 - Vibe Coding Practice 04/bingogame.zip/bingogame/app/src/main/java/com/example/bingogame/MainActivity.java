package com.example.bingogame;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView[][] bingoGrid = new TextView[5][5];
    private Random random = new Random();
    private boolean[][] marked = new boolean[5][5];  // Track marked cells

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Initialize Grid (same as before)
        bingoGrid[0][0] = findViewById(R.id.text1);
        bingoGrid[0][1] = findViewById(R.id.text2);
        bingoGrid[0][2] = findViewById(R.id.text3);
        bingoGrid[0][3] = findViewById(R.id.text4);
        bingoGrid[0][4] = findViewById(R.id.text5);
        bingoGrid[1][0] = findViewById(R.id.text6);
        bingoGrid[1][1] = findViewById(R.id.text7);
        bingoGrid[1][2] = findViewById(R.id.text8);
        bingoGrid[1][3] = findViewById(R.id.text9);
        bingoGrid[1][4] = findViewById(R.id.text10);
        bingoGrid[2][0] = findViewById(R.id.text11);
        bingoGrid[2][1] = findViewById(R.id.text12);
        bingoGrid[2][2] = findViewById(R.id.text13);
        bingoGrid[2][3] = findViewById(R.id.text14);
        bingoGrid[2][4] = findViewById(R.id.text15);
        bingoGrid[3][0] = findViewById(R.id.text16);
        bingoGrid[3][1] = findViewById(R.id.text17);
        bingoGrid[3][2] = findViewById(R.id.text18);
        bingoGrid[3][3] = findViewById(R.id.text19);
        bingoGrid[3][4] = findViewById(R.id.text20);
        bingoGrid[4][0] = findViewById(R.id.text21);
        bingoGrid[4][1] = findViewById(R.id.text22);
        bingoGrid[4][2] = findViewById(R.id.text23);
        bingoGrid[4][3] = findViewById(R.id.text24);
        bingoGrid[4][4] = findViewById(R.id.text25);

        Button checkButton = findViewById(R.id.checkButton);
        checkButton.setText("Mark Random");  // Better text
        checkButton.setOnClickListener(v -> markRandomAndCheckWin());
        ImageView ivSettings = findViewById(R.id.ivSettings);
        ivSettings.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, ConfigActivity.class));
        });
    }

    /** Mark random unmarked cell GREEN + check for BINGO */
    private void markRandomAndCheckWin() {
        // Find first unmarked cell
        int row = -1, col = -1;
        do {
            row = random.nextInt(5);
            col = random.nextInt(5);
        } while (marked[row][col]);  // Skip already marked

        // Mark it GREEN
        bingoGrid[row][col].setBackgroundColor(Color.GREEN);
        marked[row][col] = true;

        // CHECK WIN CONDITIONS
        if (checkBingoWin()) {
            showWinDialog();
        }
    }

    /** Check ALL 12 possible BINGO lines */
    private boolean checkBingoWin() {
        // 1. Check 5 ROWS
        for (int i = 0; i < 5; i++) {
            if (isLineComplete(i, 0, 0, 1)) return true;  // row i
        }

        // 2. Check 5 COLUMNS
        for (int j = 0; j < 5; j++) {
            if (isLineComplete(0, j, 1, 0)) return true;  // column j
        }

        // 3. Check MAIN DIAGONAL (0,0 → 4,4)
        if (isLineComplete(0, 0, 1, 1)) return true;

        // 4. Check ANTI-DIAGONAL (0,4 → 4,0)
        if (isLineComplete(0, 4, 1, -1)) return true;

        return false;
    }

    /** Helper: Check if line from (startRow, startCol) with (dRow, dCol) is complete */
    private boolean isLineComplete(int startRow, int startCol, int dRow, int dCol) {
        for (int i = 0; i < 5; i++) {
            int r = startRow + i * dRow;
            int c = startCol + i * dCol;
            if (!marked[r][c]) return false;
        }
        return true;
    }

    /** Show WIN popup */
    private void showWinDialog() {
        new AlertDialog.Builder(this)
                .setTitle("🎉 BINGO! 🎉")
                .setMessage("WIN!\nYou got BINGO!")
                .setPositiveButton("Play Again", (dialog, which) -> resetGame())
                .setNegativeButton("Exit", (dialog, which) -> finish())
                .setCancelable(false)
                .show();

        // Also show Toast
        Toast.makeText(this, "WIN! 🎉", Toast.LENGTH_LONG).show();
    }

    /** Reset game for new round */
    private void resetGame() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                // Reset background (keep original colors)
                bingoGrid[i][j].setBackgroundColor(Color.TRANSPARENT);
                marked[i][j] = false;
            }
        }
        Toast.makeText(this, "New game started!", Toast.LENGTH_SHORT).show();
    }
}